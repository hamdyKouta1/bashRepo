#!/usr/bin/bash

x=10

. ./s2_s.sh

