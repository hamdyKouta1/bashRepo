#!/usr/bin/bash

export x=5

./s2.sh
