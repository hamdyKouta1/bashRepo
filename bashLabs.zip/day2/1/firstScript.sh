#!/usr/bin/bash
echo hello please enter your name
read name
echo hello $name

