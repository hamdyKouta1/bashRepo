#!/usr/bin/bash
source_file="$1"
destination_file="$2"

cp "$source_file" "$destination_file"

